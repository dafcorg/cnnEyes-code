import numpy as np
from sklearn.metrics import f1_score, roc_auc_score, average_precision_score

def multilabel_metrics(y_true,y_prob,thresholds=None):
    y_true=np.asarray(y_true).astype(int); y_prob=np.asarray(y_prob)
    if thresholds is None: thresholds=np.full(y_true.shape[1],.5)
    y_pred=(y_prob>=thresholds).astype(int)
    out={
        "macro_f1":float(f1_score(y_true,y_pred,average="macro",zero_division=0)),
        "micro_f1":float(f1_score(y_true,y_pred,average="micro",zero_division=0)),
        "f1_per_class":f1_score(y_true,y_pred,average=None,zero_division=0).tolist()
    }
    try: out["macro_auroc"]=float(roc_auc_score(y_true,y_prob,average="macro"))
    except Exception: out["macro_auroc"]=None
    try: out["macro_auprc"]=float(average_precision_score(y_true,y_prob,average="macro"))
    except Exception: out["macro_auprc"]=None
    return out

def optimize_thresholds(y_true,y_prob):
    thresholds=[]
    for c in range(y_true.shape[1]):
        best_t,best_f=.5,-1
        for t in np.linspace(.05,.95,37):
            pred=(y_prob[:,c]>=t).astype(int)
            f=f1_score(y_true[:,c],pred,zero_division=0)
            if f>best_f: best_f,best_t=f,t
        thresholds.append(float(best_t))
    return np.array(thresholds)
