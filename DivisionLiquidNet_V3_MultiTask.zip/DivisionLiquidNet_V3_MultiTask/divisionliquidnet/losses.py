import torch
import torch.nn.functional as F

def asymmetric_loss(logits, targets, gamma_neg=4, gamma_pos=1, clip=.05, eps=1e-8):
    p=torch.sigmoid(logits)
    p_neg=(1-p+clip).clamp(max=1)
    pos=targets*torch.log(p.clamp(min=eps))
    neg=(1-targets)*torch.log(p_neg.clamp(min=eps))
    loss=pos+neg
    pt= p*targets + (1-p)*(1-targets)
    gamma=gamma_pos*targets+gamma_neg*(1-targets)
    loss=loss*((1-pt).clamp(min=0)**gamma)
    return -loss.mean()

def spatial_sparsity_loss(spatial_probs):
    # Weak regularizer only: discourages trivial all-on maps without forcing tiny regions.
    return spatial_probs.mean()

def counterfactual_drop_loss(original_logits, erased_logits, positive_targets):
    # Encourage predictions for known positive labels to fall after their top evidence is erased.
    delta=original_logits-erased_logits
    valid=positive_targets
    if valid.sum()==0: return original_logits.new_tensor(0.)
    return F.relu(0.15-delta)[valid.bool()].mean()

def total_loss(outputs, targets, cfg):
    tr=cfg["training"]
    l_global=asymmetric_loss(outputs["global_logits"],targets)
    l_mil=asymmetric_loss(outputs["mil_logits"],targets)
    l_fused=asymmetric_loss(outputs["logits"],targets)
    l_spatial=spatial_sparsity_loss(outputs["spatial_probs"])
    # Auxiliary targets derived from the five rare-disease labels: G,C,A,H,M.
    rare = targets[:, [2,3,4,5,6]]
    count = rare.sum(dim=1)
    individual_target = (count == 1).float()
    coexist_target = (count >= 2).float()
    l_aux = (F.binary_cross_entropy_with_logits(outputs["individual_logits"], individual_target)
             + F.binary_cross_entropy_with_logits(outputs["coexistence_logits"], coexist_target))
    total=(tr["lambda_global"]*l_global + tr["lambda_mil"]*l_mil
           + 0.5*l_fused + tr["lambda_aux"]*l_aux
           + tr["lambda_spatial_reg"]*l_spatial)
    parts={"global":l_global,"mil":l_mil,"fused":l_fused,"aux":l_aux,"spatial_reg":l_spatial}
    return total,parts
