import argparse, torch, numpy as np
from PIL import Image
from pathlib import Path
from .model import DivisionLiquidNetV3
from .utils import save_json
import matplotlib.pyplot as plt

LABELS=["N","D","G","C","A","H","M","O"]
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--checkpoint",required=True); ap.add_argument("--image",required=True)
    ap.add_argument("--output",default="inference_output"); ap.add_argument("--size",type=int,default=512)
    a=ap.parse_args(); outdir=Path(a.output); outdir.mkdir(parents=True,exist_ok=True)
    ck=torch.load(a.checkpoint,map_location="cpu",weights_only=False); cfg=ck["config"]
    model=DivisionLiquidNetV3(8,cfg["model"]["width"],cfg["model"]["dropout"],cfg["model"]["topk_fraction"])
    model.load_state_dict(ck["model"]); model.eval()
    img=Image.open(a.image).convert("RGB").resize((a.size,a.size))
    x=torch.from_numpy(np.asarray(img,dtype=np.float32)/255.).permute(2,0,1).unsqueeze(0)
    with torch.no_grad(): o=model(x)
    probs=torch.sigmoid(o["logits"])[0].numpy()
    maps=o["spatial_probs"][0].numpy()
    thresholds=np.array(ck.get("thresholds",[.5]*8))
    results={LABELS[i]:{"probability":float(probs[i]),"predicted":bool(probs[i]>=thresholds[i]),
                        "threshold":float(thresholds[i])} for i in range(8)}
    save_json({"image":a.image,"classification":results,
               "localization_type":"weakly_supervised_evidence_map_not_clinical_segmentation"},outdir/"prediction.json")
    imgarr=np.asarray(img)
    for i,label in enumerate(LABELS):
        fig,ax=plt.subplots(figsize=(7,6))
        ax.imshow(imgarr); ax.imshow(maps[i],cmap="jet",alpha=.42,vmin=0,vmax=1)
        ax.set_title(f"{label} — evidence map"); ax.axis("off")
        fig.tight_layout(); fig.savefig(outdir/f"map_{label}.png",dpi=160); plt.close(fig)
    print("Resultados guardados en",outdir)
if __name__=="__main__": main()
