import argparse
from .utils import load_config, ensure_dir
from .data import build_manifest, audit_manifest
import json
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--config",default="configs/odir.yaml")
    a=ap.parse_args(); cfg=load_config(a.config); ensure_dir(cfg["data"]["output_dir"])
    df=build_manifest(cfg); report=audit_manifest(df,cfg["data"]["output_dir"])
    print(json.dumps(report,indent=2,ensure_ascii=False))
if __name__=="__main__": main()
