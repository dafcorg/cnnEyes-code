import torch
from torch import nn
import torch.nn.functional as F

class ConvBNAct(nn.Module):
    def __init__(self, cin, cout, k=3, stride=1):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(cin,cout,k,stride,k//2,bias=False),
            nn.BatchNorm2d(cout), nn.SiLU(inplace=True))
    def forward(self,x): return self.block(x)

class ResidualBlock(nn.Module):
    def __init__(self, cin, cout, stride=1):
        super().__init__()
        self.a = ConvBNAct(cin,cout,3,stride)
        self.b = nn.Sequential(nn.Conv2d(cout,cout,3,1,1,bias=False),nn.BatchNorm2d(cout))
        self.skip = nn.Identity() if cin==cout and stride==1 else nn.Sequential(
            nn.Conv2d(cin,cout,1,stride,bias=False),nn.BatchNorm2d(cout))
        self.act = nn.SiLU(inplace=True)
    def forward(self,x): return self.act(self.b(self.a(x))+self.skip(x))

class Encoder(nn.Module):
    def __init__(self,width=32):
        super().__init__()
        self.stem = ConvBNAct(3,width,3,2)
        self.e1 = ResidualBlock(width,width,1)       # 1/2
        self.e2 = nn.Sequential(ResidualBlock(width,width*2,2),ResidualBlock(width*2,width*2))
        self.e3 = nn.Sequential(ResidualBlock(width*2,width*4,2),ResidualBlock(width*4,width*4))
        self.e4 = nn.Sequential(ResidualBlock(width*4,width*8,2),ResidualBlock(width*8,width*8))
        self.e5 = nn.Sequential(ResidualBlock(width*8,width*8,2),ResidualBlock(width*8,width*8))
    def forward(self,x):
        x=self.e1(self.stem(x))
        a=self.e2(x); b=self.e3(a); c=self.e4(b); d=self.e5(c)
        return [x,a,b,c,d]

class AttentionGate(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.g = nn.Conv2d(channels,channels,1)
        self.x = nn.Conv2d(channels,channels,1)
        self.psi = nn.Sequential(nn.SiLU(),nn.Conv2d(channels,1,1),nn.Sigmoid())
    def forward(self, skip, gate):
        return skip * self.psi(self.g(gate)+self.x(skip))

class UpBlock(nn.Module):
    def __init__(self, cin, cskip, cout):
        super().__init__()
        self.proj = ConvBNAct(cin,cout,1)
        self.skip_proj = ConvBNAct(cskip,cout,1)
        self.attn = AttentionGate(cout)
        self.fuse = nn.Sequential(ResidualBlock(cout*2,cout),ResidualBlock(cout,cout))
    def forward(self,x,skip):
        x=F.interpolate(x,size=skip.shape[-2:],mode="bilinear",align_corners=False)
        x=self.proj(x); s=self.skip_proj(skip); s=self.attn(s,x)
        return self.fuse(torch.cat([x,s],dim=1))

class SpatialDecoder(nn.Module):
    def __init__(self,width=32,n_classes=8):
        super().__init__()
        self.u4=UpBlock(width*8,width*8,width*8)
        self.u3=UpBlock(width*8,width*4,width*4)
        self.u2=UpBlock(width*4,width*2,width*2)
        self.u1=UpBlock(width*2,width,width)
        self.refine=nn.Sequential(ConvBNAct(width,width),nn.Dropout2d(.1))
        self.head=nn.Conv2d(width,n_classes,1)
    def forward(self,features,out_size):
        x=self.u4(features[4],features[3])
        x=self.u3(x,features[2]); x=self.u2(x,features[1]); x=self.u1(x,features[0])
        x=F.interpolate(self.refine(x),size=out_size,mode="bilinear",align_corners=False)
        return self.head(x)

class DivisionLiquidNetV3(nn.Module):
    def __init__(self,n_classes=8,width=32,dropout=.15,topk_fraction=.05):
        super().__init__()
        self.encoder=Encoder(width)
        self.dropout=nn.Dropout(dropout)
        self.global_head=nn.Linear(width*8,n_classes)
        self.rare_head=nn.Linear(width*8,5)       # G,C,A,H,M
        self.individual_head=nn.Linear(width*8,1)
        self.coexistence_head=nn.Linear(width*8,1)
        self.decoder=SpatialDecoder(width,n_classes)
        self.topk_fraction=topk_fraction
    def forward(self,x):
        feats=self.encoder(x)
        pooled=F.adaptive_avg_pool2d(feats[-1],1).flatten(1)
        pooled=self.dropout(pooled)
        global_logits=self.global_head(pooled)
        rare_logits=self.rare_head(pooled)
        # MIL scores from each disease-specific spatial logit map.
        spatial_logits=self.decoder(feats,x.shape[-2:])
        flat=spatial_logits.flatten(2)
        k=max(1,int(flat.shape[-1]*self.topk_fraction))
        mil_logits=flat.topk(k,dim=-1).values.mean(-1)
        # Fused classification logits; separate heads retained for ablation.
        fused_logits=global_logits + 0.5*mil_logits
        return {
            "logits":fused_logits, "global_logits":global_logits,
            "mil_logits":mil_logits, "rare_logits":rare_logits,
            "individual_logits":self.individual_head(pooled).squeeze(1),
            "coexistence_logits":self.coexistence_head(pooled).squeeze(1),
            "spatial_logits":spatial_logits,
            "spatial_probs":torch.sigmoid(spatial_logits),
            "features":feats
        }
