import argparse, json, time
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader
from torch.cuda.amp import autocast, GradScaler
from tqdm import tqdm
from .utils import load_config, seed_everything, ensure_dir, save_json
from .data import build_manifest, split_by_patient, audit_manifest, FundusDataset, LABELS
from .model import DivisionLiquidNetV3
from .losses import total_loss
from .metrics import multilabel_metrics, optimize_thresholds
from .energy import EnergyMonitor

def run_epoch(model,loader,optimizer,scaler,device,cfg,train=True,epoch=0,split="train"):
    model.train(train); losses=[]; all_y=[]; all_p=[]
    monitor=EnergyMonitor(cfg["energy"]["enabled"],cfg["energy"]["sample_interval_seconds"])
    monitor.start(); start=time.time()
    pbar=tqdm(loader,desc=f"{split} {epoch}",leave=False)
    for batch in pbar:
        x=batch["image"].to(device,non_blocking=True); y=batch["labels"].to(device,non_blocking=True)
        if train: optimizer.zero_grad(set_to_none=True)
        with torch.set_grad_enabled(train):
            with autocast(enabled=(device.type=="cuda" and cfg["training"]["amp"])):
                out=model(x); loss,parts=total_loss(out,y,cfg)
            if train:
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(),cfg["training"]["grad_clip_norm"])
                scaler.step(optimizer); scaler.update()
        losses.append(float(loss.detach().cpu()))
        all_y.append(y.detach().cpu().numpy())
        all_p.append(torch.sigmoid(out["logits"]).detach().cpu().numpy())
        pbar.set_postfix(loss=f"{np.mean(losses):.4f}")
    energy=monitor.stop(); monitor.close()
    elapsed=time.time()-start
    y=np.concatenate(all_y); p=np.concatenate(all_p)
    return float(np.mean(losses)),y,p,{"wall_time_s":elapsed,**energy}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--config",default="configs/odir.yaml")
    ap.add_argument("--output",default=None)
    args=ap.parse_args()
    cfg=load_config(args.config); seed_everything(cfg["seed"])
    outdir=Path(args.output or cfg["data"]["output_dir"]); ensure_dir(outdir)
    df=build_manifest(cfg); audit=audit_manifest(df,outdir)
    print(json.dumps(audit,indent=2,ensure_ascii=False))
    if not cfg["data"]["assume_exhaustive_labels"]:
        raise RuntimeError(
          "Entrenamiento detenido por seguridad: ODIR keyword ausente no se ha confirmado como negativo. "
          "Audita dataset_audit.json y manifest_warnings.csv. Si verificas exhaustividad, cambia "
          "data.assume_exhaustive_labels=true. Si no, implementa priors PU validados antes de entrenar."
        )
    train_df,val_df,test_df=split_by_patient(df,cfg["data"]["validation_fraction"],cfg["data"]["test_fraction"],cfg["seed"])
    for name,part in [("train",train_df),("val",val_df),("test",test_df)]:
        part.to_json(outdir/f"{name}_split.json",orient="records",indent=2)
        print(name, "images",len(part),"patients",part.patient_id.nunique(),
              "positive_counts",np.asarray(part.labels.tolist()).sum(0).tolist())
    size=cfg["data"]["image_size"]; bs=cfg["data"]["batch_size"]
    loaders={
      "train":DataLoader(FundusDataset(train_df,size,True),batch_size=bs,shuffle=True,num_workers=cfg["data"]["num_workers"],pin_memory=True),
      "val":DataLoader(FundusDataset(val_df,size,False),batch_size=bs,shuffle=False,num_workers=cfg["data"]["num_workers"],pin_memory=True),
      "test":DataLoader(FundusDataset(test_df,size,False),batch_size=bs,shuffle=False,num_workers=cfg["data"]["num_workers"],pin_memory=True)
    }
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model=DivisionLiquidNetV3(8,cfg["model"]["width"],cfg["model"]["dropout"],cfg["model"]["topk_fraction"]).to(device)
    optimizer=torch.optim.AdamW(model.parameters(),lr=cfg["training"]["learning_rate"],weight_decay=cfg["training"]["weight_decay"])
    scaler=GradScaler(enabled=(device.type=="cuda" and cfg["training"]["amp"]))
    best=-1; bad=0; history=[]
    for epoch in range(1,cfg["training"]["epochs"]+1):
        tr=run_epoch(model,loaders["train"],optimizer,scaler,device,cfg,True,epoch,"train")
        va=run_epoch(model,loaders["val"],optimizer,scaler,device,cfg,False,epoch,"val")
        val_loss,vy,vp,ve=va
        # Thresholds fixed at .5 for checkpoint selection; tune on validation after training.
        metrics=multilabel_metrics(vy,vp)
        row={"epoch":epoch,"train_loss":tr[0],"val_loss":val_loss,
             "train_energy":tr[3],"val_energy":ve,"val_metrics":metrics}
        history.append(row); print(json.dumps(row,ensure_ascii=False))
        score=metrics["macro_f1"]
        if score>best:
            best=score; bad=0
            torch.save({"model":model.state_dict(),"config":cfg,"epoch":epoch,"val_macro_f1":best},outdir/"best.pt")
        else: bad+=1
        if cfg["training"]["save_every_epoch"]:
            torch.save({"model":model.state_dict(),"config":cfg,"epoch":epoch},outdir/f"epoch_{epoch:03d}.pt")
        save_json(history,outdir/"history.json")
        if bad>=cfg["training"]["patience"]:
            print(f"Early stopping en época {epoch}."); break
    ckpt=torch.load(outdir/"best.pt",map_location=device,weights_only=False)
    model.load_state_dict(ckpt["model"])
    _,vy,vp,_=run_epoch(model,loaders["val"],optimizer,scaler,device,cfg,False,0,"threshold-calibration")
    thresholds=optimize_thresholds(vy,vp)
    _,ty,tp,te=run_epoch(model,loaders["test"],optimizer,scaler,device,cfg,False,0,"test")
    test_metrics=multilabel_metrics(ty,tp,thresholds)
    save_json({"thresholds":thresholds.tolist(),"test_metrics":test_metrics,"test_energy":te,
               "best_epoch":ckpt["epoch"]},outdir/"final_results.json")
    torch.save({"model":model.state_dict(),"config":cfg,"thresholds":thresholds.tolist()},outdir/"best_with_thresholds.pt")
    print("TEST:",json.dumps(test_metrics,indent=2))
    print("Resultados:",outdir)

if __name__=="__main__": main()
