from pathlib import Path
import hashlib, re
import numpy as np
import pandas as pd
from PIL import Image, ImageEnhance
import torch
from torch.utils.data import Dataset
from sklearn.model_selection import GroupShuffleSplit

LABELS = ["N", "D", "G", "C", "A", "H", "M", "O"]

def _norm(x):
    if pd.isna(x): return ""
    return str(x).strip().lower()

def keyword_to_labels(keyword_text, patterns):
    text = _norm(keyword_text)
    y = np.zeros(len(LABELS), dtype=np.float32)
    unknown = []
    if not text:
        return y, unknown
    # ODIR keywords are usually semicolon-separated, but matching the full text
    # also supports comma-separated or free-text variants.
    for i, label in enumerate(LABELS):
        for pattern in patterns.get(label, []):
            if re.search(re.escape(pattern.lower()), text):
                y[i] = 1.0
                break
    known_terms = [p.lower() for vals in patterns.values() for p in vals]
    terms = [t.strip() for t in re.split(r"[;,|]", text) if t.strip()]
    for term in terms:
        if not any(p in term for p in known_terms):
            unknown.append(term)
    return y, sorted(set(unknown))

def build_manifest(cfg):
    d = cfg["data"]; pats = cfg["labels"]["patterns"]
    excel = Path(d["excel_path"]); image_root = Path(d["image_root"])
    if not excel.exists(): raise FileNotFoundError(f"No existe Excel: {excel}")
    if not image_root.exists(): raise FileNotFoundError(f"No existe carpeta de imágenes: {image_root}")
    df = pd.read_excel(excel)
    required = [d["patient_id_column"], d["left_image_column"], d["right_image_column"],
                d["left_keyword_column"], d["right_keyword_column"]]
    missing = [c for c in required if c not in df.columns]
    if missing: raise ValueError(f"Faltan columnas en Excel: {missing}. Columnas encontradas: {list(df.columns)}")
    rows, unknown = [], []
    for _, r in df.iterrows():
        pid = str(r[d["patient_id_column"]])
        for side, img_col, kw_col in [
            ("L", d["left_image_column"], d["left_keyword_column"]),
            ("R", d["right_image_column"], d["right_keyword_column"])
        ]:
            fname = str(r[img_col]).strip()
            if not fname or fname.lower() == "nan": continue
            path = image_root / fname
            if not path.exists():
                # Case-insensitive fallback for file systems with case differences.
                matches = [p for p in image_root.iterdir() if p.name.lower() == fname.lower()]
                if matches: path = matches[0]
            if not path.exists():
                unknown.append({"patient_id":pid, "side":side, "missing_image":fname})
                continue
            y, unk = keyword_to_labels(r[kw_col], pats)
            for term in unk: unknown.append({"patient_id":pid,"side":side,"unknown_keyword":term})
            rows.append({"patient_id":pid,"side":side,"image_path":str(path),
                         "keywords":_norm(r[kw_col]),"labels":y.tolist()})
    if not rows: raise RuntimeError("No se encontraron imágenes válidas.")
    out = pd.DataFrame(rows)
    out.to_json(Path(d["output_dir"])/"manifest.json", orient="records", indent=2)
    pd.DataFrame(unknown).to_csv(Path(d["output_dir"])/"manifest_warnings.csv", index=False)
    return out

def split_by_patient(df, val_fraction, test_fraction, seed):
    groups = df["patient_id"].astype(str).values
    idx = np.arange(len(df))
    test_split = GroupShuffleSplit(n_splits=1, test_size=test_fraction, random_state=seed)
    trainval_idx, test_idx = next(test_split.split(idx, groups=groups))
    relative_val = val_fraction / (1.0 - test_fraction)
    val_split = GroupShuffleSplit(n_splits=1, test_size=relative_val, random_state=seed+1)
    tr_rel, va_rel = next(val_split.split(trainval_idx, groups=groups[trainval_idx]))
    train_idx, val_idx = trainval_idx[tr_rel], trainval_idx[va_rel]
    return df.iloc[train_idx].reset_index(drop=True), df.iloc[val_idx].reset_index(drop=True), df.iloc[test_idx].reset_index(drop=True)

def audit_manifest(df, output_dir):
    Y = np.asarray(df["labels"].tolist(), dtype=int)
    report = {
        "images": len(df),
        "unique_patients": int(df["patient_id"].nunique()),
        "positive_counts_by_label": dict(zip(LABELS, Y.sum(0).tolist())),
        "observed_positive_rates": dict(zip(LABELS, Y.mean(0).tolist())),
        "cooccurrence": (Y.T @ Y).tolist(),
        "keyword_examples": df["keywords"].value_counts().head(30).to_dict()
    }
    # Exact file duplicate detection
    hashes = {}
    for p in df["image_path"]:
        try:
            h = hashlib.sha256(Path(p).read_bytes()).hexdigest()
            hashes.setdefault(h, []).append(str(p))
        except OSError: pass
    report["exact_duplicate_groups"] = [v for v in hashes.values() if len(v)>1]
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    import json
    with open(Path(output_dir)/"dataset_audit.json","w",encoding="utf-8") as f:
        json.dump(report,f,indent=2,ensure_ascii=False)
    return report

class FundusDataset(Dataset):
    def __init__(self, frame, image_size=512, augment=False):
        self.frame = frame.reset_index(drop=True)
        self.image_size = image_size; self.augment = augment
    def __len__(self): return len(self.frame)
    def __getitem__(self, i):
        row = self.frame.iloc[i]
        img = Image.open(row.image_path).convert("RGB").resize((self.image_size,self.image_size), Image.Resampling.BILINEAR)
        if self.augment:
            if np.random.rand() < .5: img = img.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
            if np.random.rand() < .15: img = img.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
            if np.random.rand() < .5:
                img = ImageEnhance.Brightness(img).enhance(float(np.random.uniform(.85,1.15)))
                img = ImageEnhance.Contrast(img).enhance(float(np.random.uniform(.85,1.15)))
        arr = np.asarray(img,dtype=np.float32)/255.0
        # ImageNet normalization is not assumed; use stable [0,1] scaling.
        x = torch.from_numpy(arr).permute(2,0,1).contiguous()
        y = torch.tensor(row.labels,dtype=torch.float32)
        return {"image":x,"labels":y,"patient_id":str(row.patient_id),"image_path":str(row.image_path)}
