import time, threading, csv
from pathlib import Path

class EnergyMonitor:
    """
    GPU-board energy monitor.
    Uses NVML total-energy counter when available; otherwise integrates sampled power.
    This is NOT whole-system energy and does not include CPU, display, storage, etc.
    """
    def __init__(self, enabled=True, interval=.25, csv_path=None):
        self.enabled=enabled; self.interval=interval; self.csv_path=csv_path
        self.available=False; self.handle=None; self.nvml=None
        self._stop=threading.Event(); self._thread=None
        self.samples=[]; self.start_energy_mj=None; self.start_time=None
        self._integrated_j=0.0; self._last_power_w=None; self._last_t=None
        if enabled:
            try:
                import pynvml
                pynvml.nvmlInit()
                self.nvml=pynvml
                self.handle=pynvml.nvmlDeviceGetHandleByIndex(0)
                self.available=True
            except Exception:
                self.available=False
    def _total_energy(self):
        try:
            return self.nvml.nvmlDeviceGetTotalEnergyConsumption(self.handle)
        except Exception:
            return None
    def _power(self):
        try: return self.nvml.nvmlDeviceGetPowerUsage(self.handle)/1000.0
        except Exception: return None
    def _sample_loop(self):
        while not self._stop.wait(self.interval):
            now=time.time(); p=self._power()
            if p is not None:
                if self._last_power_w is not None:
                    dt=now-self._last_t
                    self._integrated_j += (self._last_power_w+p)*0.5*dt
                self._last_power_w=p; self._last_t=now
                self.samples.append({"timestamp":now,"power_w":p})
    def start(self):
        if not self.enabled or not self.available:
            self.start_time=time.time(); return
        self.samples=[]; self._integrated_j=0.0; self._last_power_w=None
        self.start_energy_mj=self._total_energy(); self.start_time=time.time()
        self._stop.clear()
        self._thread=threading.Thread(target=self._sample_loop,daemon=True); self._thread.start()
    def stop(self):
        end=time.time()
        if self._thread:
            self._stop.set(); self._thread.join(timeout=2)
        duration=(end-self.start_time) if self.start_time else 0
        end_energy=self._total_energy() if self.available else None
        if self.start_energy_mj is not None and end_energy is not None:
            energy_j=max(0,(end_energy-self.start_energy_mj)/1000.0)
            method="nvml_total_energy"
        elif self.available:
            energy_j=self._integrated_j; method="integrated_nvml_power"
        else:
            energy_j=None; method="unavailable"
        avg=(energy_j/duration) if energy_j is not None and duration>0 else None
        result={"duration_s":duration,"gpu_energy_j":energy_j,"average_gpu_power_w":avg,
                "measurement":method,"gpu_monitor_available":self.available}
        if self.csv_path and self.samples:
            p=Path(self.csv_path); p.parent.mkdir(parents=True,exist_ok=True)
            with open(p,"w",newline="") as f:
                w=csv.DictWriter(f,fieldnames=["timestamp","power_w"]); w.writeheader(); w.writerows(self.samples)
        return result
    def close(self):
        if self.nvml:
            try: self.nvml.nvmlShutdown()
            except Exception: pass
