# DivisionLiquidNet V3 Multi-Task

Implementación PyTorch para ODIR-5K con:
- clasificación multietiqueta de ocho categorías;
- encoder CNN multiescala propio;
- decoder espacial con ocho mapas de evidencia;\n- cabezas auxiliares de aprendizaje individual/coexistente para G,C,A,H,M;
- agregación Multiple Instance Learning (MIL) Top-K;
- mapas de evidencia por enfermedad exportables;
- auditoría de keywords y duplicados;
- particiones agrupadas por paciente;
- monitorización de energía GPU mediante NVML por fase/época.

## Advertencia científica esencial

ODIR-5K proporciona etiquetas a nivel de imagen, no máscaras pixel a pixel. Esta implementación aprende **mapas de evidencia/localización débilmente supervisada**, no segmentación clínica validada. Los mapas no deben interpretarse como contornos reales de lesiones.

La rama espacial se supervisa indirectamente mediante MIL: las puntuaciones de las regiones se agregan y contribuyen a la clasificación global. La regularización espacial es débil para evitar mapas triviales.

## Instalación

```bash
conda create -n divisionliquidnet_v3 python=3.11 -y
conda activate divisionliquidnet_v3
pip install -r requirements.txt
```

Instala PyTorch según tu versión de CUDA desde https://pytorch.org/get-started/locally/.

## Estructura de datos esperada

```text
data/
└── ODIR-5K/
    ├── ODIR-5K_training.xlsx
    └── Training Images/
        ├── ...
```

Ajusta `configs/odir.yaml` si los nombres/rutas difieren. Se esperan las columnas:
`ID`, `Left-Fundus`, `Right-Fundus`, `Left-Diagnostic Keywords`, `Right-Diagnostic Keywords`.

## Paso 1: auditoría

```bash
python scripts/audit_odir.py --config configs/odir.yaml
```

Revisa:
- `runs/divisionliquidnet_v3/dataset_audit.json`
- `runs/divisionliquidnet_v3/manifest_warnings.csv`
- `runs/divisionliquidnet_v3/manifest.json`

Corrige `labels.patterns` según el vocabulario real. No asumas que las keywords ausentes son negativos sin comprobar el protocolo de anotación.

## Paso 2: confirmar semántica de etiquetas

Por defecto el entrenamiento se detiene porque la ausencia de una keyword no se convierte automáticamente en negativo.

Si confirmas documentalmente que las etiquetas por ojo son exhaustivas, cambia:
```yaml
data:
  assume_exhaustive_labels: true
```

Si no son exhaustivas, no actives esa opción: esta versión no implementa todavía una pérdida Positive-Unlabeled (PU) validada. No basta con poner a cero las etiquetas ausentes. En ese caso debe adaptarse el objetivo de clasificación antes de entrenar.

## Paso 3: entrenamiento

```bash
python -m divisionliquidnet.train --config configs/odir.yaml
```

El split se agrupa por `ID` para mantener ambos ojos del paciente en una sola partición. Se guardan índices de train/validation/test para reproducibilidad. GroupShuffleSplit no garantiza estratificación multilabel; inspecciona los conteos por partición.

## Paso 4: inferencia y mapas

```bash
python -m divisionliquidnet.infer \
  --checkpoint runs/divisionliquidnet_v3/best_with_thresholds.pt \
  --image "ruta/a/imagen.jpg" \
  --output inference_output
```

Genera `prediction.json` y ocho mapas `map_N.png`, `map_D.png`, etc.

## Monitorización energética

Se usa NVML (`pynvml`) para medir energía de la GPU:
- Preferencia: contador acumulado de energía de la placa GPU, cuando el dispositivo lo soporta.
- Alternativa: integración temporal de muestras de potencia GPU.
- Se registra duración y energía por época/fase.

**No es consumo total del ordenador**: no incluye CPU, RAM, pantalla, almacenamiento ni pérdidas de la fuente. En algunos dispositivos/driver el contador de energía no está disponible. En ese caso el código intenta integrar potencia muestreada; si tampoco está disponible, devuelve `unavailable`.

Para medición de sistema completo hace falta un medidor externo o telemetría específica de plataforma.

## Limitaciones y próximos desarrollos

1. Revisar y mejorar los patrones de keywords de ODIR con el Excel real.
2. Confirmar exhaustividad o incorporar PU learning validado.
3. Añadir calibración y evaluación de estabilidad de mapas.
4. Implementar borrado contrafactual con una segunda pasada solo tras estabilizar el baseline.
5. Validar localización con anotaciones expertas externas (puntos o máscaras) sin contaminar el test.
6. Las máscaras de segmentación real requieren anotaciones pixel a pixel.
7. Las etiquetas `N` y `O` no equivalen a regiones anatómicas segmentables; las salidas son mapas de evidencia asociados a etiquetas.

Este proyecto es un prototipo de investigación, no un dispositivo ni software médico validado.
