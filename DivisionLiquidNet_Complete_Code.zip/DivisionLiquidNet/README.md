# DivisionLiquidNet — prototipo de investigación

## Objetivo
Clasificación multietiqueta de ocho categorías de ODIR-5K a partir de imágenes de fondo de ojo, sin máscaras de segmentación. Incluye un extractor CNN multiescala, routing clínico, grafo de relaciones entre etiquetas, Grad-CAM por clase y simulación sintética de escenarios.

## Instalación
Entorno recomendado: Python 3.10–3.12 y PyTorch compatible con tu CUDA.

```bash
pip install torch torchvision pandas numpy pillow scikit-learn matplotlib openpyxl pynvml
```

`pynvml` es opcional; permite estimar energía de la GPU NVIDIA. Sin él, se registra tiempo, pero no energía.

## Estructura esperada
```text
ODIR-5K/
  data.xlsx
  Training Images/
    0_left.jpg
    0_right.jpg
    ...
```
El archivo puede ser CSV o XLSX y debe contener columnas `ID`, `Left-Fundus`, `Right-Fundus` y las etiquetas `N,D,G,C,A,H,M,O`.

## Ejecutar escenarios sintéticos
```bash
python divisionliquidnet.py --mode simulate
```
Los valores son proxies sintéticos para probar la política del controlador; no son resultados clínicos ni mediciones de energía.

## Entrenar
```bash
python divisionliquidnet.py \
  --mode train \
  --csv "./ODIR-5K/data.xlsx" \
  --image-root "./ODIR-5K/Training Images" \
  --output "./runs/divisionliquidnet" \
  --epochs 40 --batch-size 16 --image-size 384
```

El split agrupa por paciente para impedir que ambos ojos queden en particiones distintas. Se recomienda verificar que el identificador del CSV representa realmente al paciente.

## Explicaciones
```bash
python divisionliquidnet.py --mode explain \
  --image "./ODIR-5K/Training Images/0_left.jpg" \
  --checkpoint "./runs/divisionliquidnet/best_model.pt" \
  --output "./runs/divisionliquidnet"
```
Genera un mapa Grad-CAM por etiqueta. Los mapas son explicaciones del modelo, no segmentaciones ni localizaciones clínicas validadas.

## Archivos de salida
- `best_model.pt`: mejores pesos según AUPRC de validación.
- `results.json`: métricas, umbrales y limitaciones.
- `history.csv`: pérdida, métricas, tiempo y energía estimada por época.

## Limitaciones científicas que deben resolverse antes de publicar
1. El routing actual evalúa las tres ramas expertas en paralelo. Los pesos del router son un proxy de asignación; no implican ahorro real de FLOPs, latencia o energía. Para demostrar ahorro se necesita despacho condicional real y medición en el hardware objetivo.
2. El `quality_head` no tiene supervisión de calidad en ODIR-5K; su salida no debe interpretarse como calidad fiable hasta añadir etiquetas o una tarea auxiliar validada.
3. Las etiquetas ODIR son normalmente de nivel paciente y se replican a ambos ojos en este loader. Esto puede introducir ruido si el diagnóstico no corresponde a cada ojo. Debe documentarse y, si es posible, armonizar con anotación por ojo.
4. El split por grupos evita fuga entre ojos, pero no es una partición multietiqueta estratificada perfecta. Revisar prevalencias por partición.
5. Los umbrales se optimizan en validación; el test se usa una sola vez al final.
6. No hay máscaras: no se puede afirmar Dice/IoU ni exactitud de localización de lesiones.
7. El prototipo no es un dispositivo médico y no debe usarse para diagnóstico clínico.
