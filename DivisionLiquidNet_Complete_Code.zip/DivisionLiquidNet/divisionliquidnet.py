#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DivisionLiquidNet — ODIR-5K multi-label fundus classification.
Research prototype; not a medical device and not clinically validated.

Features:
- Patient-grouped train/validation/test split (prevents left/right-eye leakage).
- Eight-label multi-label classification.
- Morphological multi-scale CNN encoder.
- Clinical relevance routing with low/medium/high refinement experts.
- Learned disease co-occurrence refinement.
- Per-class Grad-CAM explanations.
- Synthetic routing scenario simulator.
- Optional NVIDIA GPU energy measurement via NVML.

Important:
The routing module is a learnable computational-allocation proxy. In this
prototype, expert branches are evaluated in parallel; therefore routing scores
do NOT guarantee lower hardware energy. Actual savings require conditional
kernel execution / compiled sparse dispatch and must be measured on target HW.
"""

import argparse
import copy
import json
import math
import os
import random
import time
import threading
from dataclasses import dataclass, asdict
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageEnhance

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import (
    f1_score, precision_score, recall_score, roc_auc_score,
    average_precision_score, hamming_loss
)

LABELS = ["N", "D", "G", "C", "A", "H", "M", "O"]
LABEL_NAMES = {
    "N": "Normal", "D": "Diabetes", "G": "Glaucoma",
    "C": "Cataract", "A": "AMD", "H": "Hypertension",
    "M": "Pathological myopia", "O": "Other"
}


def seed_everything(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


@dataclass
class Config:
    csv_path: str = "./ODIR-5K/data.xlsx"
    image_root: str = "./ODIR-5K/Training Images"
    output_dir: str = "./runs/divisionliquidnet"
    image_size: int = 384
    batch_size: int = 16
    epochs: int = 40
    learning_rate: float = 2e-4
    weight_decay: float = 1e-4
    num_workers: int = 4
    seed: int = 42
    train_fraction: float = 0.70
    val_fraction: float = 0.15
    use_amp: bool = True
    use_asymmetric_loss: bool = True
    gamma_neg: float = 4.0
    gamma_pos: float = 1.0
    clip: float = 0.05
    label_smoothing: float = 0.0
    threshold: float = 0.5
    routing_temperature: float = 1.0
    routing_cost_weight: float = 0.002
    cooccurrence_weight: float = 0.01
    energy_budget_j_per_image: float = 0.0  # 0 disables budget penalty
    patience: int = 8
    device: str = "cuda" if torch.cuda.is_available() else "cpu"


class FundusDataset(Dataset):
    """One sample per eye; patient ID is retained for grouped splitting."""
    def __init__(self, frame, image_root, image_size=384, train=False):
        self.frame = frame.reset_index(drop=True)
        self.root = Path(image_root)
        self.train = train
        if train:
            self.tf = transforms.Compose([
                transforms.Resize((image_size, image_size)),
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.RandomRotation(degrees=12),
                transforms.ColorJitter(brightness=0.12, contrast=0.12, saturation=0.10),
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406],
                                     [0.229, 0.224, 0.225]),
            ])
        else:
            self.tf = transforms.Compose([
                transforms.Resize((image_size, image_size)),
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406],
                                     [0.229, 0.224, 0.225]),
            ])

    def __len__(self):
        return len(self.frame)

    def __getitem__(self, idx):
        row = self.frame.iloc[idx]
        path = self.root / str(row["image_file"])
        try:
            image = Image.open(path).convert("RGB")
        except Exception as exc:
            raise RuntimeError(f"Could not read image: {path}") from exc
        x = self.tf(image)
        y = torch.tensor(row[LABELS].to_numpy(dtype=np.float32), dtype=torch.float32)
        return x, y, str(row["patient_id"]), str(path)


def _find_column(df, candidates):
    lower = {str(c).strip().lower(): c for c in df.columns}
    for c in candidates:
        if c.lower() in lower:
            return lower[c.lower()]
    return None


def load_odir_table(csv_path, image_root):
    """Supports ODIR CSV/XLSX exports with common column naming."""
    p = str(csv_path)
    if p.lower().endswith((".xlsx", ".xls")):
        raw = pd.read_excel(p)
    else:
        raw = pd.read_csv(p)

    id_col = _find_column(raw, ["ID", "Patient ID", "patient_id"])
    left_col = _find_column(raw, ["Left-Fundus", "Left Fundus", "left_fundus"])
    right_col = _find_column(raw, ["Right-Fundus", "Right Fundus", "right_fundus"])
    if id_col is None or left_col is None or right_col is None:
        raise ValueError(
            "Could not identify ID, Left-Fundus and Right-Fundus columns. "
            f"Available columns: {list(raw.columns)}"
        )

    missing = [c for c in LABELS if c not in raw.columns]
    if missing:
        raise ValueError(f"Missing ODIR label columns: {missing}")

    records = []
    for _, r in raw.iterrows():
        pid = str(r[id_col])
        labels = {k: float(r[k]) for k in LABELS}
        for col in (left_col, right_col):
            filename = str(r[col]).strip()
            if not filename or filename.lower() == "nan":
                continue
            full = Path(image_root) / filename
            if not full.exists():
                # Keep relative filename; dataset will report a precise error.
                rel = filename
            else:
                rel = filename
            records.append({"patient_id": pid, "image_file": rel, **labels})

    data = pd.DataFrame(records)
    # ODIR's Normal label is mutually exclusive by definition in the dataset.
    # Do not silently rewrite labels; report contradictions for inspection.
    contradiction = ((data["N"] > 0) & (data[[x for x in LABELS if x != "N"]].sum(axis=1) > 0))
    if contradiction.any():
        print(f"WARNING: {int(contradiction.sum())} eye-records have Normal and pathology labels.")
    return data


def patient_level_split(df, seed=42, train_fraction=0.70, val_fraction=0.15):
    """Group split by patient. Avoids splitting two eyes across partitions."""
    groups = df["patient_id"].astype(str).to_numpy()
    idx = np.arange(len(df))
    gss1 = GroupShuffleSplit(n_splits=1, train_size=train_fraction, random_state=seed)
    train_idx, rest_idx = next(gss1.split(idx, groups=groups))
    rest = df.iloc[rest_idx].reset_index(drop=True)
    rest_groups = rest["patient_id"].astype(str).to_numpy()
    val_share_of_rest = val_fraction / (1.0 - train_fraction)
    gss2 = GroupShuffleSplit(n_splits=1, train_size=val_share_of_rest,
                             random_state=seed + 1)
    val_rel, test_rel = next(gss2.split(np.arange(len(rest)), groups=rest_groups))
    train = df.iloc[train_idx].reset_index(drop=True)
    val = rest.iloc[val_rel].reset_index(drop=True)
    test = rest.iloc[test_rel].reset_index(drop=True)

    # Explicit leakage assertion.
    a, b, c = set(train.patient_id), set(val.patient_id), set(test.patient_id)
    assert not (a & b or a & c or b & c), "Patient leakage detected."
    return train, val, test


class ConvBNAct(nn.Module):
    def __init__(self, cin, cout, kernel=3, stride=1, groups=1):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(cin, cout, kernel, stride, kernel // 2,
                      groups=groups, bias=False),
            nn.BatchNorm2d(cout),
            nn.SiLU(inplace=True)
        )
    def forward(self, x):
        return self.block(x)


class ResidualDepthBlock(nn.Module):
    def __init__(self, channels, expansion=2):
        super().__init__()
        hidden = channels * expansion
        self.net = nn.Sequential(
            ConvBNAct(channels, hidden, 1),
            ConvBNAct(hidden, hidden, 3, groups=hidden),
            nn.Conv2d(hidden, channels, 1, bias=False),
            nn.BatchNorm2d(channels)
        )
        self.act = nn.SiLU(inplace=True)
    def forward(self, x):
        return self.act(x + self.net(x))


class MorphologicalFeatureExtractor(nn.Module):
    """Multi-scale learned feature extraction; no segmentation masks required."""
    def __init__(self, width=32):
        super().__init__()
        self.stem = nn.Sequential(
            ConvBNAct(3, width, 3, 2),
            ConvBNAct(width, width, 3)
        )
        self.stage1 = nn.Sequential(
            ResidualDepthBlock(width),
            ResidualDepthBlock(width)
        )
        self.down2 = ConvBNAct(width, width * 2, 3, 2)
        self.stage2 = nn.Sequential(
            ResidualDepthBlock(width * 2),
            ResidualDepthBlock(width * 2)
        )
        self.down3 = ConvBNAct(width * 2, width * 4, 3, 2)
        self.stage3 = nn.Sequential(
            ResidualDepthBlock(width * 4),
            ResidualDepthBlock(width * 4)
        )
        self.proj1 = nn.Conv2d(width, width * 4, 1)
        self.proj2 = nn.Conv2d(width * 2, width * 4, 1)
        self.fuse = nn.Sequential(
            ConvBNAct(width * 12, width * 4, 1),
            ResidualDepthBlock(width * 4)
        )
        self.out_channels = width * 4

    def forward(self, x):
        x1 = self.stage1(self.stem(x))
        x2 = self.stage2(self.down2(x1))
        x3 = self.stage3(self.down3(x2))
        size = x3.shape[-2:]
        p1 = F.adaptive_avg_pool2d(self.proj1(x1), size)
        p2 = F.adaptive_avg_pool2d(self.proj2(x2), size)
        fused = self.fuse(torch.cat([p1, p2, x3], dim=1))
        return fused


class RareSignalProtection(nn.Module):
    """Preserves high-frequency feature responses that may encode small findings."""
    def __init__(self, channels: int, out_dim: int = 128):
        super().__init__()
        self.project = nn.Sequential(
            ConvBNAct(channels, channels, 1),
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(channels, out_dim),
            nn.SiLU(inplace=True),
        )

    def forward(self, feature_map):
        smooth = F.avg_pool2d(feature_map, kernel_size=3, stride=1, padding=1)
        high_frequency = feature_map - smooth
        return self.project(high_frequency)


class ClinicalRelevanceRouter(nn.Module):
    """
    Predicts low/medium/high refinement weights for every spatial location.
    Branches are evaluated in parallel in this research prototype.
    """
    def __init__(self, channels, temperature=1.0):
        super().__init__()
        self.temperature = temperature
        hidden = max(16, channels // 4)
        self.gate = nn.Sequential(
            nn.Conv2d(channels, hidden, 1),
            nn.SiLU(inplace=True),
            nn.Conv2d(hidden, 3, 1)
        )
        self.expert_low = nn.Sequential(
            nn.Conv2d(channels, channels, 1, groups=1, bias=False),
            nn.BatchNorm2d(channels), nn.SiLU(inplace=True)
        )
        self.expert_mid = nn.Sequential(
            ConvBNAct(channels, channels, 3, groups=channels),
            nn.Conv2d(channels, channels, 1, bias=False),
            nn.BatchNorm2d(channels), nn.SiLU(inplace=True)
        )
        self.expert_high = nn.Sequential(
            ConvBNAct(channels, channels, 5, groups=channels),
            nn.Conv2d(channels, channels, 1, bias=False),
            nn.BatchNorm2d(channels), nn.SiLU(inplace=True),
            ResidualDepthBlock(channels)
        )
        self.register_buffer("route_costs", torch.tensor([1.0, 2.0, 3.5]))

    def forward(self, x):
        logits = self.gate(x) / max(self.temperature, 1e-4)
        weights = torch.softmax(logits, dim=1)
        low = self.expert_low(x)
        mid = self.expert_mid(x)
        high = self.expert_high(x)
        stack = torch.stack([low, mid, high], dim=1)
        out = (stack * weights.unsqueeze(2)).sum(dim=1)
        expected_cost = (weights * self.route_costs.view(1, 3, 1, 1)).sum(dim=1)
        route_entropy = -(weights.clamp_min(1e-8) * weights.clamp_min(1e-8).log()).sum(1)
        stats = {
            "weights": weights,
            "expected_cost": expected_cost.mean(),
            "route_entropy": route_entropy.mean()
        }
        return x + out, stats


class DiseaseRelationshipHead(nn.Module):
    """Learned label graph with bounded residual message passing."""
    def __init__(self, feature_dim, n_labels=8):
        super().__init__()
        self.classifier = nn.Linear(feature_dim, n_labels)
        self.graph_logits = nn.Parameter(torch.zeros(n_labels, n_labels))
        self.message_scale = nn.Parameter(torch.tensor(0.1))
        self.norm = nn.LayerNorm(n_labels)

    def forward(self, pooled):
        base = self.classifier(pooled)
        adjacency = torch.sigmoid(self.graph_logits)
        adjacency = 0.5 * (adjacency + adjacency.T)
        adjacency = adjacency - torch.diag(torch.diag(adjacency))
        adjacency = adjacency / adjacency.sum(dim=-1, keepdim=True).clamp_min(1e-6)
        messages = torch.sigmoid(base) @ adjacency.T
        refined = base + self.message_scale * torch.logit(
            messages.clamp(1e-4, 1 - 1e-4)
        )
        return self.norm(refined), base, adjacency


class DivisionLiquidNet(nn.Module):
    def __init__(self, width=32, n_labels=8, routing_temperature=1.0):
        super().__init__()
        self.encoder = MorphologicalFeatureExtractor(width)
        c = self.encoder.out_channels
        self.router = ClinicalRelevanceRouter(c, routing_temperature)
        self.attention = nn.Sequential(
            nn.Conv2d(c, c // 4, 1), nn.SiLU(inplace=True),
            nn.Conv2d(c // 4, 1, 1), nn.Sigmoid()
        )
        self.dropout = nn.Dropout(0.25)
        self.head = DiseaseRelationshipHead(c, n_labels)
        self.quality_head = nn.Sequential(
            nn.Linear(c, c // 2), nn.SiLU(), nn.Linear(c // 2, 1)
        )
        self.last_feature_map = None
        self.last_attention_map = None

    def forward(self, x):
        feat = self.encoder(x)
        feat, route_stats = self.router(feat)
        attn = self.attention(feat)
        attended = feat * (0.5 + attn)
        self.last_feature_map = attended
        self.last_attention_map = attn
        pooled = F.adaptive_avg_pool2d(attended, 1).flatten(1)
        pooled = self.dropout(pooled)
        logits, base_logits, adjacency = self.head(pooled)
        quality_logit = self.quality_head(pooled).squeeze(1)
        return {
            "logits": logits,
            "base_logits": base_logits,
            "adjacency": adjacency,
            "route": route_stats,
            "quality_logit": quality_logit,
            "features": attended
        }


class AsymmetricLoss(nn.Module):
    """Asymmetric multi-label loss, suitable for imbalanced positive/negative labels."""
    def __init__(self, gamma_neg=4, gamma_pos=1, clip=0.05, eps=1e-8):
        super().__init__()
        self.gn, self.gp, self.clip, self.eps = gamma_neg, gamma_pos, clip, eps

    def forward(self, logits, targets):
        xs_pos = torch.sigmoid(logits)
        xs_neg = 1.0 - xs_pos
        if self.clip > 0:
            xs_neg = (xs_neg + self.clip).clamp(max=1)
        loss_pos = targets * torch.log(xs_pos.clamp_min(self.eps))
        loss_neg = (1 - targets) * torch.log(xs_neg.clamp_min(self.eps))
        pt = xs_pos * targets + xs_neg * (1 - targets)
        gamma = self.gp * targets + self.gn * (1 - targets)
        return -(((1 - pt) ** gamma) * (loss_pos + loss_neg)).mean()


def compute_loss(output, targets, criterion, cfg):
    cls_loss = criterion(output["logits"], targets)
    # Mild graph regularization; discourages unstable, excessively dense relations.
    graph = output["adjacency"]
    graph_reg = graph.abs().mean()
    route_cost = output["route"]["expected_cost"]
    total = cls_loss + cfg.cooccurrence_weight * graph_reg
    total = total + cfg.routing_cost_weight * route_cost
    return total, {
        "classification": float(cls_loss.detach()),
        "graph_reg": float(graph_reg.detach()),
        "route_cost": float(route_cost.detach())
    }


class NVMLMeter:
    """Samples GPU power and integrates joules. Requires nvidia-ml-py."""
    def __init__(self, interval=0.1):
        self.interval = interval
        self.available = False
        self.running = False
        self.joules = 0.0
        self._thread = None
        try:
            import pynvml
            pynvml.nvmlInit()
            self.nvml = pynvml
            self.handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            self.available = True
        except Exception:
            self.available = False

    def _sample(self):
        last = time.perf_counter()
        while self.running:
            try:
                mw = self.nvml.nvmlDeviceGetPowerUsage(self.handle)
                now = time.perf_counter()
                self.joules += (mw / 1000.0) * (now - last)
                last = now
            except Exception:
                pass
            time.sleep(self.interval)

    def start(self):
        if self.available:
            self.joules = 0.0
            self.running = True
            self._thread = threading.Thread(target=self._sample, daemon=True)
            self._thread.start()

    def stop(self):
        if self.available:
            self.running = False
            if self._thread:
                self._thread.join(timeout=2)
            return self.joules
        return None


def safe_auc(y_true, y_prob, average):
    try:
        return float(roc_auc_score(y_true, y_prob, average=average))
    except Exception:
        return float("nan")


def calculate_metrics(y_true, y_prob, thresholds=None):
    thresholds = np.asarray(thresholds if thresholds is not None else [0.5] * len(LABELS))
    y_pred = (y_prob >= thresholds.reshape(1, -1)).astype(int)
    per_class = {}
    for i, label in enumerate(LABELS):
        yt, yp = y_true[:, i], y_pred[:, i]
        try:
            ap = float(average_precision_score(yt, y_prob[:, i]))
        except Exception:
            ap = float("nan")
        per_class[label] = {
            "f1": float(f1_score(yt, yp, zero_division=0)),
            "precision": float(precision_score(yt, yp, zero_division=0)),
            "recall_sensitivity": float(recall_score(yt, yp, zero_division=0)),
            "auprc": ap,
            "prevalence": float(np.mean(yt))
        }
    return {
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "micro_f1": float(f1_score(y_true, y_pred, average="micro", zero_division=0)),
        "macro_auroc": safe_auc(y_true, y_prob, "macro"),
        "micro_auroc": safe_auc(y_true, y_prob, "micro"),
        "macro_auprc": float(np.nanmean([v["auprc"] for v in per_class.values()])),
        "hamming_loss": float(hamming_loss(y_true, y_pred)),
        "per_class": per_class
    }


@torch.no_grad()
def predict(model, loader, device, amp=False):
    model.eval()
    ys, ps, routes, qualities = [], [], [], []
    for x, y, _, _ in loader:
        x = x.to(device, non_blocking=True)
        with torch.autocast(device_type="cuda", enabled=amp and device.startswith("cuda")):
            out = model(x)
        prob = torch.sigmoid(out["logits"]).float().cpu().numpy()
        ys.append(y.numpy())
        ps.append(prob)
        routes.append(float(out["route"]["expected_cost"].cpu()))
        qualities.extend(torch.sigmoid(out["quality_logit"]).cpu().tolist())
    return np.concatenate(ys), np.concatenate(ps), {
        "mean_route_cost": float(np.mean(routes)),
        "quality_scores": qualities
    }


def train_one_epoch(model, loader, optimizer, scaler, criterion, cfg, device, nvml):
    model.train()
    nvml.start()
    total, n = 0.0, 0
    parts = {}
    optimizer.zero_grad(set_to_none=True)
    for x, y, _, _ in loader:
        x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device_type="cuda", enabled=cfg.use_amp and device.startswith("cuda")):
            out = model(x)
            loss, detail = compute_loss(out, y, criterion, cfg)
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        scaler.step(optimizer)
        scaler.update()
        bs = x.size(0)
        total += float(loss.detach()) * bs
        n += bs
        for k, v in detail.items():
            parts[k] = parts.get(k, 0.0) + v * bs
    energy = nvml.stop()
    return total / max(n, 1), {k: v / max(n, 1) for k, v in parts.items()}, energy


def tune_thresholds(y_true, y_prob):
    thresholds = []
    for i in range(y_true.shape[1]):
        best_t, best_f = 0.5, -1
        # Validation-only threshold selection.
        for t in np.linspace(0.10, 0.90, 17):
            pred = (y_prob[:, i] >= t).astype(int)
            score = f1_score(y_true[:, i], pred, zero_division=0)
            if score > best_f:
                best_t, best_f = float(t), float(score)
        thresholds.append(best_t)
    return thresholds


def train(cfg):
    seed_everything(cfg.seed)
    os.makedirs(cfg.output_dir, exist_ok=True)
    device = cfg.device
    print(f"Device: {device}")
    df = load_odir_table(cfg.csv_path, cfg.image_root)
    train_df, val_df, test_df = patient_level_split(
        df, cfg.seed, cfg.train_fraction, cfg.val_fraction
    )
    print(f"Images: train={len(train_df)}, val={len(val_df)}, test={len(test_df)}")
    print(f"Patients: train={train_df.patient_id.nunique()}, "
          f"val={val_df.patient_id.nunique()}, test={test_df.patient_id.nunique()}")

    train_ds = FundusDataset(train_df, cfg.image_root, cfg.image_size, True)
    val_ds = FundusDataset(val_df, cfg.image_root, cfg.image_size, False)
    test_ds = FundusDataset(test_df, cfg.image_root, cfg.image_size, False)
    common = dict(batch_size=cfg.batch_size, num_workers=cfg.num_workers,
                  pin_memory=device.startswith("cuda"))
    train_loader = DataLoader(train_ds, shuffle=True, **common)
    val_loader = DataLoader(val_ds, shuffle=False, **common)
    test_loader = DataLoader(test_ds, shuffle=False, **common)

    model = DivisionLiquidNet(width=32, n_labels=len(LABELS),
                              routing_temperature=cfg.routing_temperature).to(device)
    criterion = (AsymmetricLoss(cfg.gamma_neg, cfg.gamma_pos, cfg.clip)
                 if cfg.use_asymmetric_loss else nn.BCEWithLogitsLoss())
    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg.learning_rate,
                                  weight_decay=cfg.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=cfg.epochs)
    scaler = torch.amp.GradScaler("cuda", enabled=cfg.use_amp and device.startswith("cuda"))
    nvml = NVMLMeter()

    best_score, best_state, stale = -1, None, 0
    history = []
    for epoch in range(1, cfg.epochs + 1):
        t0 = time.perf_counter()
        tr_loss, loss_parts, energy = train_one_epoch(
            model, train_loader, optimizer, scaler, criterion, cfg, device, nvml
        )
        yv, pv, route_info = predict(model, val_loader, device, cfg.use_amp)
        val_metrics = calculate_metrics(yv, pv)
        scheduler.step()
        elapsed = time.perf_counter() - t0
        energy_per_image = (energy / len(train_ds)) if energy is not None else None
        row = {
            "epoch": epoch, "train_loss": tr_loss, **loss_parts,
            "val_macro_f1": val_metrics["macro_f1"],
            "val_macro_auprc": val_metrics["macro_auprc"],
            "val_macro_auroc": val_metrics["macro_auroc"],
            "mean_route_cost": route_info["mean_route_cost"],
            "epoch_seconds": elapsed, "gpu_energy_j": energy,
            "gpu_j_per_train_image": energy_per_image
        }
        history.append(row)
        print(json.dumps(row, ensure_ascii=False))
        # AUPRC is more informative for imbalanced labels; F1 breaks ties.
        score = val_metrics["macro_auprc"]
        if not np.isfinite(score):
            score = val_metrics["macro_f1"]
        if score > best_score:
            best_score, stale = score, 0
            best_state = copy.deepcopy(model.state_dict())
            torch.save(best_state, os.path.join(cfg.output_dir, "best_model.pt"))
        else:
            stale += 1
        if stale >= cfg.patience:
            print(f"Early stopping at epoch {epoch}")
            break

    if best_state is not None:
        model.load_state_dict(best_state)

    yv, pv, _ = predict(model, val_loader, device, cfg.use_amp)
    thresholds = tune_thresholds(yv, pv)
    yt, pt, test_info = predict(model, test_loader, device, cfg.use_amp)
    test_metrics = calculate_metrics(yt, pt, thresholds)

    result = {
        "config": asdict(cfg),
        "labels": LABELS,
        "thresholds": thresholds,
        "test_metrics": test_metrics,
        "test_route_cost": test_info["mean_route_cost"],
        "history": history,
        "limitations": [
            "No lesion masks are used or inferred as ground truth.",
            "Quality head is not supervised unless quality labels are added.",
            "Routing experts are parallel in this prototype; route cost is not measured energy.",
            "NVML energy is GPU-board energy estimate, not whole-system energy."
        ]
    }
    with open(os.path.join(cfg.output_dir, "results.json"), "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    pd.DataFrame(history).to_csv(os.path.join(cfg.output_dir, "history.csv"), index=False)
    print("Test metrics:")
    print(json.dumps(test_metrics, indent=2, ensure_ascii=False))
    return model, thresholds


def simulate_scenarios():
    """
    Deterministic synthetic routing stress test.
    These are controller behavior scenarios, NOT clinical performance results.
    """
    scenarios = {
        "normal_clear":       {"uncertainty": 0.05, "rare_signal": 0.02, "quality": 0.98, "budget": 3.0},
        "obvious_disease":    {"uncertainty": 0.20, "rare_signal": 0.10, "quality": 0.95, "budget": 3.0},
        "ambiguous":          {"uncertainty": 0.85, "rare_signal": 0.25, "quality": 0.90, "budget": 3.0},
        "multiple_diseases":  {"uncertainty": 0.60, "rare_signal": 0.45, "quality": 0.92, "budget": 3.5},
        "rare_disease":       {"uncertainty": 0.55, "rare_signal": 0.95, "quality": 0.90, "budget": 3.0},
        "low_quality":        {"uncertainty": 0.90, "rare_signal": 0.20, "quality": 0.20, "budget": 3.0},
        "tight_energy":       {"uncertainty": 0.60, "rare_signal": 0.70, "quality": 0.90, "budget": 1.8},
    }
    rows = []
    for name, s in scenarios.items():
        # Proposed controller policy: protect rare signals, increase compute for uncertainty,
        # reduce compute for poor quality (but flag the image rather than infer confidently).
        demand = 1.0 + 1.4 * s["uncertainty"] + 1.2 * s["rare_signal"]
        demand *= (0.65 + 0.35 * s["quality"])
        allocated = min(demand, s["budget"])
        if s["quality"] < 0.4:
            status = "low_quality_review"
        elif s["rare_signal"] > 0.7 and allocated < demand:
            status = "rare_signal_protected_budget_warning"
        elif s["uncertainty"] > 0.7:
            status = "high_compute_uncertain"
        elif allocated <= 1.5:
            status = "light_route"
        else:
            status = "adaptive_route"
        rows.append({
            "scenario": name, **s, "compute_demand_proxy": round(demand, 3),
            "allocated_compute_proxy": round(allocated, 3),
            "status": status
        })
    return rows


def gradcam_for_class(model, image_tensor, class_index, device):
    """Grad-CAM for one class. Returns a normalized 2D numpy heatmap."""
    model.eval()
    x = image_tensor.unsqueeze(0).to(device)
    activations, gradients = {}, {}

    def fwd_hook(_m, _i, out):
        activations["value"] = out

    def bwd_hook(_m, _gi, go):
        gradients["value"] = go[0]

    target_layer = model.encoder.stage3[-1]
    h1 = target_layer.register_forward_hook(fwd_hook)
    h2 = target_layer.register_full_backward_hook(bwd_hook)
    model.zero_grad(set_to_none=True)
    out = model(x)
    out["logits"][0, class_index].backward()
    a = activations["value"]
    g = gradients["value"]
    weights = g.mean(dim=(2, 3), keepdim=True)
    cam = torch.relu((weights * a).sum(dim=1, keepdim=True))
    cam = F.interpolate(cam, size=image_tensor.shape[-2:], mode="bilinear",
                        align_corners=False)[0, 0]
    cam = cam.detach().cpu().numpy()
    cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
    h1.remove()
    h2.remove()
    return cam


def export_explanations(model, cfg, image_path, output_dir, device):
    import matplotlib.pyplot as plt
    os.makedirs(output_dir, exist_ok=True)
    tf = transforms.Compose([
        transforms.Resize((cfg.image_size, cfg.image_size)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225])
    ])
    img = Image.open(image_path).convert("RGB")
    x = tf(img)
    model.eval()
    with torch.no_grad():
        out = model(x.unsqueeze(0).to(device))
        probs = torch.sigmoid(out["logits"])[0].cpu().numpy()
    for i, label in enumerate(LABELS):
        cam = gradcam_for_class(model, x, i, device)
        plt.figure(figsize=(6, 6))
        plt.imshow(img.resize((cfg.image_size, cfg.image_size)))
        plt.imshow(cam, cmap="jet", alpha=0.38)
        plt.axis("off")
        plt.title(f"{LABEL_NAMES[label]}: p={probs[i]:.3f}")
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, f"gradcam_{label}.png"), dpi=160)
        plt.close()
    with open(os.path.join(output_dir, "predictions.json"), "w") as f:
        json.dump({LABEL_NAMES[k]: float(probs[i]) for i, k in enumerate(LABELS)},
                  f, indent=2)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["train", "simulate", "explain"], default="train")
    parser.add_argument("--csv", default="./ODIR-5K/data.xlsx")
    parser.add_argument("--image-root", default="./ODIR-5K/Training Images")
    parser.add_argument("--output", default="./runs/divisionliquidnet")
    parser.add_argument("--image", default="")
    parser.add_argument("--checkpoint", default="")
    parser.add_argument("--epochs", type=int, default=40)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--image-size", type=int, default=384)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    if args.mode == "simulate":
        print(json.dumps(simulate_scenarios(), indent=2, ensure_ascii=False))
        return

    cfg = Config(
        csv_path=args.csv, image_root=args.image_root, output_dir=args.output,
        epochs=args.epochs, batch_size=args.batch_size,
        image_size=args.image_size, num_workers=args.workers, seed=args.seed
    )
    if args.mode == "train":
        train(cfg)
    else:
        if not args.image or not args.checkpoint:
            parser.error("--mode explain requires --image and --checkpoint")
        model = DivisionLiquidNet().to(cfg.device)
        model.load_state_dict(torch.load(args.checkpoint, map_location=cfg.device))
        export_explanations(model, cfg, args.image, os.path.join(args.output, "explanations"), cfg.device)


if __name__ == "__main__":
    main()
