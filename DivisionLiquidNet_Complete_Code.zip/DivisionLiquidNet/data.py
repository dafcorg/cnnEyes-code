from __future__ import annotations
import os, re
from pathlib import Path
from typing import Dict, List
import numpy as np
import pandas as pd
from PIL import Image
import torch
from torch.utils.data import Dataset
from torchvision import transforms
from divisionliquidnet import LABELS, quality_metrics, quality_dict_to_tensor

# Keyword mapping is intentionally explicit and editable. Review it against the annotation
# vocabulary in the user's ODIR release before relying on it.
KEYWORD_MAP = {
    "N": ["normal fundus"],
    "D": ["diabetic retinopathy", "diabetes", "proliferative diabetic retinopathy",
          "nonproliferative diabetic retinopathy", "mild nonproliferative",
          "moderate non proliferative", "severe non proliferative"],
    "G": ["glaucoma", "glaucomatous"],
    "C": ["cataract", "lens opacity"],
    "A": ["age-related macular degeneration", "amd", "macular degeneration"],
    "H": ["hypertension", "hypertensive retinopathy"],
    "M": ["pathological myopia", "pathologic myopia", "high myopia", "myopia"],
    "O": ["other", "retinal vein occlusion", "branch retinal vein occlusion",
          "central retinal vein occlusion", "epiretinal membrane", "macular hole",
          "optic neuropathy", "retinitis", "choroidal", "vascular occlusion"],
}

def keywords_to_labels(value) -> np.ndarray:
    text = str(value).lower()
    y = np.zeros(len(LABELS), dtype=np.float32)
    for i, label in enumerate(LABELS):
        for term in KEYWORD_MAP[label]:
            if term in text:
                y[i] = 1.0
                break
    # "Normal" is mutually exclusive in the original annotation convention.
    # Do not infer Normal merely because no disease keyword was matched.
    return y


def build_records_from_odir_excel(xlsx_path, image_root):
    df = pd.read_excel(xlsx_path)
    required = ["Left-Fundus", "Right-Fundus",
                "Left-Diagnostic Keywords", "Right-Diagnostic Keywords"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(
            f"Faltan columnas ODIR: {missing}. Columnas disponibles: {list(df.columns)}. "
            "No se replicarán etiquetas entre ojos."
        )
    id_col = "ID" if "ID" in df.columns else None
    records = []
    for _, row in df.iterrows():
        patient_id = str(row[id_col]) if id_col else str(_)
        for side, img_col, kw_col in [
            ("L", "Left-Fundus", "Left-Diagnostic Keywords"),
            ("R", "Right-Fundus", "Right-Diagnostic Keywords"),
        ]:
            filename = str(row[img_col]).strip()
            if not filename or filename.lower() == "nan":
                continue
            path = Path(image_root) / filename
            if not path.exists():
                # Some ODIR folders contain subdirectories; try recursive filename match.
                matches = list(Path(image_root).rglob(Path(filename).name))
                if matches:
                    path = matches[0]
            if not path.exists():
                continue
            labels = keywords_to_labels(row[kw_col])
            records.append({
                "image_path": str(path),
                "patient_id": patient_id,
                "eye": side,
                "labels": labels,
            })
    return records


def load_manifest(csv_path):
    """Manifest columns: image_path, patient_id, N,D,G,C,A,H,M,O."""
    df = pd.read_csv(csv_path)
    needed = ["image_path", "patient_id"] + LABELS
    missing = [c for c in needed if c not in df.columns]
    if missing:
        raise ValueError(f"El CSV debe contener columnas: {needed}. Faltan: {missing}")
    records = []
    for _, row in df.iterrows():
        records.append({
            "image_path": str(row["image_path"]),
            "patient_id": str(row["patient_id"]),
            "eye": str(row["eye"]) if "eye" in df.columns else "",
            "labels": row[LABELS].astype(float).to_numpy(dtype=np.float32),
        })
    return records


class FundusDataset(Dataset):
    def __init__(self, records, image_size=512, augment=False):
        self.records = records
        ops = [transforms.Resize((image_size, image_size))]
        if augment:
            ops += [
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.RandomRotation(degrees=10),
                transforms.ColorJitter(brightness=0.12, contrast=0.12, saturation=0.08),
            ]
        ops += [transforms.ToTensor(),
                transforms.Normalize(mean=(0.485, 0.456, 0.406),
                                     std=(0.229, 0.224, 0.225))]
        self.transform = transforms.Compose(ops)

    def __len__(self):
        return len(self.records)

    def __getitem__(self, idx):
        rec = self.records[idx]
        image = Image.open(rec["image_path"]).convert("RGB")
        q = quality_dict_to_tensor(quality_metrics(image))
        x = self.transform(image)
        y = torch.tensor(rec["labels"], dtype=torch.float32)
        return x, y, q, rec["patient_id"], rec["image_path"]
