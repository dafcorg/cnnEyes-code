import argparse, json
import numpy as np
import torch
from PIL import Image
from torchvision import transforms
from divisionliquidnet import DivisionLiquidNet, LABELS, quality_metrics, quality_dict_to_tensor

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--image", required=True)
    p.add_argument("--image-size", type=int, default=512)
    p.add_argument("--threshold", type=float, default=0.5)
    args = p.parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    ckpt = torch.load(args.checkpoint, map_location=device)
    model = DivisionLiquidNet().to(device)
    model.load_state_dict(ckpt["model"])
    model.eval()
    image = Image.open(args.image).convert("RGB")
    qd = quality_metrics(image)
    tfm = transforms.Compose([
        transforms.Resize((args.image_size, args.image_size)),
        transforms.ToTensor(),
        transforms.Normalize((0.485,0.456,0.406),(0.229,0.224,0.225))
    ])
    x = tfm(image).unsqueeze(0).to(device)
    q = quality_dict_to_tensor(qd).unsqueeze(0).to(device)
    with torch.no_grad():
        out = model(x, q)
        probs = torch.sigmoid(out["logits"])[0].cpu().numpy()
    print(json.dumps({
        "quality": qd,
        "predictions": {label: float(prob) for label, prob in zip(LABELS, probs)},
        "positive_labels": [label for label, prob in zip(LABELS, probs) if prob >= args.threshold],
        "selected_regions": int(out["selected_regions"].sum().item()),
        "total_regions": int(out["selected_regions"].numel()),
        "warning": "Research output only; not a medical diagnosis."
    }, indent=2))

if __name__ == "__main__":
    main()
