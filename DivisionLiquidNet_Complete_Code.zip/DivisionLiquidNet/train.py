from __future__ import annotations
import argparse, json, random, time
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader
from sklearn.model_selection import GroupShuffleSplit
from divisionliquidnet import DivisionLiquidNet, AsymmetricLoss, NVMLMonitor, multilabel_metrics, LABELS
from data import build_records_from_odir_excel, load_manifest, FundusDataset


def seed_everything(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)


def split_records(records, seed=42):
    groups = np.array([r["patient_id"] for r in records])
    idx = np.arange(len(records))
    # Split by patient to prevent left/right eyes from leaking across partitions.
    gss1 = GroupShuffleSplit(n_splits=1, test_size=0.20, random_state=seed)
    trainval_idx, test_idx = next(gss1.split(idx, groups=groups))
    trainval_groups = groups[trainval_idx]
    gss2 = GroupShuffleSplit(n_splits=1, test_size=0.20, random_state=seed + 1)
    tr_rel, val_rel = next(gss2.split(trainval_idx, groups=trainval_groups))
    train_idx = trainval_idx[tr_rel]
    val_idx = trainval_idx[val_rel]
    return ([records[i] for i in train_idx],
            [records[i] for i in val_idx],
            [records[i] for i in test_idx])


def run_epoch(model, loader, optimizer, criterion, device, scaler, train=True):
    model.train(train)
    total_loss, n = 0.0, 0
    all_y, all_p = [], []
    monitor = NVMLMonitor() if device.type == "cuda" else None
    if monitor: monitor.start()
    for x, y, q, _, _ in loader:
        x, y, q = x.to(device), y.to(device), q.to(device)
        if train: optimizer.zero_grad(set_to_none=True)
        amp_ctx = torch.autocast(device_type="cuda", dtype=torch.float16) if device.type == "cuda" else __import__("contextlib").nullcontext()
        with torch.set_grad_enabled(train):
            with amp_ctx:
                out = model(x, q)
                loss = criterion(out["logits"], y)
            if train:
                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()
        bs = x.size(0)
        total_loss += loss.item() * bs
        n += bs
        all_y.append(y.detach().cpu().numpy())
        all_p.append(torch.sigmoid(out["logits"]).detach().cpu().numpy())
    energy = monitor.stop() if monitor else {"elapsed_s": None, "gpu_energy_j_est": None, "nvml_available": False}
    if monitor: monitor.close()
    y_true = np.concatenate(all_y)
    y_prob = np.concatenate(all_p)
    return total_loss / max(n, 1), multilabel_metrics(y_true, y_prob), energy


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--odir-xlsx", type=str, default="")
    ap.add_argument("--image-root", type=str, default="")
    ap.add_argument("--manifest", type=str, default="")
    ap.add_argument("--output", type=str, default="runs/divisionliquidnet")
    ap.add_argument("--epochs", type=int, default=50)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--image-size", type=int, default=512)
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument("--top-k", type=int, default=3)
    ap.add_argument("--route-threshold", type=float, default=0.25)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    seed_everything(args.seed)
    if args.manifest:
        records = load_manifest(args.manifest)
    elif args.odir_xlsx and args.image_root:
        records = build_records_from_odir_excel(args.odir_xlsx, args.image_root)
    else:
        raise SystemExit("Indica --manifest o bien --odir-xlsx y --image-root.")
    if len(records) < 10:
        raise SystemExit(f"Solo se encontraron {len(records)} imágenes. Revisa rutas y metadatos.")
    print(f"Registros por ojo/imagen: {len(records)}")
    print("Distribución positiva:", dict(zip(LABELS, np.sum([r["labels"] for r in records], axis=0).astype(int))))

    train_r, val_r, test_r = split_records(records, args.seed)
    print(f"Split por paciente -> train={len(train_r)}, val={len(val_r)}, test={len(test_r)}")
    train_ds = FundusDataset(train_r, args.image_size, augment=True)
    val_ds = FundusDataset(val_r, args.image_size, augment=False)
    test_ds = FundusDataset(test_r, args.image_size, augment=False)
    train_dl = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                          num_workers=args.workers, pin_memory=True)
    val_dl = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False,
                        num_workers=args.workers, pin_memory=True)
    test_dl = DataLoader(test_ds, batch_size=args.batch_size, shuffle=False,
                         num_workers=args.workers, pin_memory=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = DivisionLiquidNet(top_k=args.top_k, route_threshold=args.route_threshold).to(device)
    criterion = AsymmetricLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    scaler = torch.amp.GradScaler("cuda", enabled=(device.type == "cuda"))

    out_dir = Path(args.output); out_dir.mkdir(parents=True, exist_ok=True)
    best_f1 = -1.0
    history = []
    for epoch in range(1, args.epochs + 1):
        t0 = time.perf_counter()
        tr_loss, tr_metrics, tr_energy = run_epoch(model, train_dl, optimizer, criterion, device, scaler, True)
        va_loss, va_metrics, va_energy = run_epoch(model, val_dl, optimizer, criterion, device, scaler, False)
        scheduler.step()
        elapsed = time.perf_counter() - t0
        row = {
            "epoch": epoch, "train_loss": tr_loss, "val_loss": va_loss,
            "train_metrics": tr_metrics, "val_metrics": va_metrics,
            "train_energy": tr_energy, "val_energy": va_energy,
            "epoch_wall_time_s": elapsed,
        }
        history.append(row)
        print(f"Epoch {epoch:03d}/{args.epochs} | "
              f"loss {tr_loss:.4f}/{va_loss:.4f} | "
              f"micro-F1 {tr_metrics['micro_f1']:.4f}/{va_metrics['micro_f1']:.4f} | "
              f"macro-F1 {tr_metrics['macro_f1']:.4f}/{va_metrics['macro_f1']:.4f} | "
              f"train GPU J~{tr_energy.get('gpu_energy_j_est')}")
        score = va_metrics["macro_f1"]
        if score > best_f1:
            best_f1 = score
            torch.save({"model": model.state_dict(), "epoch": epoch,
                        "labels": LABELS, "args": vars(args)}, out_dir / "best_model.pt")
        with open(out_dir / "history.json", "w", encoding="utf-8") as f:
            json.dump(history, f, indent=2)
    checkpoint = torch.load(out_dir / "best_model.pt", map_location=device)
    model.load_state_dict(checkpoint["model"])
    te_loss, te_metrics, te_energy = run_epoch(model, test_dl, optimizer, criterion, device, scaler, False)
    final = {"test_loss": te_loss, "test_metrics": te_metrics, "test_energy": te_energy,
             "best_epoch": checkpoint["epoch"]}
    with open(out_dir / "test_results.json", "w", encoding="utf-8") as f:
        json.dump(final, f, indent=2)
    print("TEST:", json.dumps(final, indent=2))


if __name__ == "__main__":
    main()
